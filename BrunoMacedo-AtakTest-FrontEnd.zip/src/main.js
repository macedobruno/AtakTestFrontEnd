import { createApp } from 'vue'
/*
import App from './App.vue'

createApp(App).mount('#app')
*/
import Search from './Search.vue'

//createApp(Search).mount('#app')
createApp(Search).mount('#search')